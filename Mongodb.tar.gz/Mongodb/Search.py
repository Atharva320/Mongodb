from pymongo import MongoClient
import certifi
from texttable import Texttable
try:
    client=MongoClient("mongodb+srv://New123:New123@cluster0.kpen7.mongodb.net/Office?retryWrites=true&w=majority",tlsCAFile=certifi.where())
    db=client["Office"]
    coll=db["Workers"]
    n = coll.count_documents({})
    print("Hello,Here you can search a worker using his ID code")
    op=input("Enter worker's ID code : ")
    match={}
    match["_ID"]=op
    for doc in coll.find(match):
        if doc:
            print('-'*50)
            print(f"Here is worker of ID code : {op}")
            t = Texttable()
            t.add_rows([['ID','Name','Salary','Mobile','Email','Post','City','Department'],[doc['_ID'],doc['Name'],doc['Salary'],doc['Mobile'],doc['Email'],doc['Post'],doc['City'],doc['Department']]])
            print(t.draw())
            print('-'*30)
        else:
            print("No such ID code!!")
except Exception as e:
    print("Some error occured,please try again!!",e)