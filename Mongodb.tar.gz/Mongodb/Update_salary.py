from io import UnsupportedOperation
from pymongo import MongoClient
import certifi
from texttable import Texttable
try:
    client=MongoClient("mongodb+srv://New123:New123@cluster0.kpen7.mongodb.net/Office?retryWrites=true&w=majority",tlsCAFile=certifi.where())
    db=client["Office"]
    coll=db["Workers"]
    n =coll.count_documents({})
    print("Hello,Here you can update salary of a worker using his ID code")
    qr={}
    Id=input('Enter Worker ID : ')
    qr["_ID"]=Id

    ch={}
    salary=int(input("Enter new salary : "))
    ch["Salary"]=salary

    option=input("Are you sure you want to update salary(Y/N) : ")
    op=option.upper()

    if op=="Y":
        upd={"$set":ch}
        coll.update_one(qr,upd)
        print(f"Salary of worker {Id} updated succesfully")
        for doc in coll.find(qr):
            t = Texttable()
            t.add_rows([['ID','Name','Salary','Mobile','Email','Post','City','Dept'],[doc['_ID'],doc['Name'],doc['Salary'],doc['Mobile'],doc['Email'],doc['Post'],doc['City'],doc['Department']]])
            print(t.draw())
    else:
        print("Byee")
        exit()
except:
    print("Some error occured try again!!")

    
