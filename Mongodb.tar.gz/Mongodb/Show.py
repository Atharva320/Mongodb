from pymongo import MongoClient
import certifi
from texttable import Texttable
try:
    client=MongoClient("mongodb+srv://New123:New123@cluster0.kpen7.mongodb.net/Office?retryWrites=true&w=majority",tlsCAFile=certifi.where())
    db=client["Office"]
    coll=db["Workers"]
    n =coll.count_documents({})
    print("Hello,Here you can see list of all workers")
    op=input('Are you sure you want to see all workers(Y/N) : ')
    print('*'*100)
    opr=op.upper()
    if opr=='Y':
        for doc in coll.find():
            t = Texttable()
            t.add_rows([['ID','Name','Salary','Mobile','Email','Post','City','Dept'],[doc['_ID'],doc['Name'],doc['Salary'],doc['Mobile'],doc['Email'],doc['Post'],doc['City'],doc['Department']]])
            print(t.draw())
            print('*'*100)
            print('*'*100)
except Exception as e:
    print("Some error occured,please try again!!",e)