from pymongo import MongoClient
import certifi
from texttable import Texttable
try:
    client=MongoClient("mongodb+srv://New123:New123@cluster0.kpen7.mongodb.net/Office?retryWrites=true&w=majority",tlsCAFile=certifi.where())
    db=client["Office"]
    coll=db["Workers"]
    n =coll.count_documents({})
    print("Hello,Here can search a worker by entering his department")
    op=input('Enter Department here : ')
    print('-'*30)
    match={}
    match["Department"]=op
    for doc in coll.find(match):
        print('-'*50)
        print(f"Here is worker of Department: {op}")
        t = Texttable()
        t.add_rows([['ID','Name','Salary','Mobile','Email','Post','City','Dept'],[doc['_ID'],doc['Name'],doc['Salary'],doc['Mobile'],doc['Email'],doc['Post'],doc['City'],doc['Department']]])
        print(t.draw())
        print('-'*30)
except Exception as e:
    print("Some error occured,please try again!!",e)