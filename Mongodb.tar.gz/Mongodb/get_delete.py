from pymongo import MongoClient
import certifi
from texttable import Texttable
try:
    client=MongoClient("mongodb+srv://New123:New123@cluster0.kpen7.mongodb.net/Office?retryWrites=true&w=majority",tlsCAFile=certifi.where())
    db=client["Office"]
    coll=db["Workers"]
    coll1=db["Exworkers"]
    print("Hello,Here you can delete a worker from Workers and add it to Exworkers")
    op=input("Enter worker's ID code : ")
    match={}
    match["_ID"]=op
    for doc in coll.find(match):
        Toadd=doc
    option=input("Are you sure you want to do this(Y/N) : ")
    op1=option.upper()
    if op1=="Y":
        coll1.insert_one(Toadd)
        coll.delete_one(match)
        print("Worker deleted and added to Exworkers succesfully!!")
    else:
        print("Byee")
        exit()
except:
    print("Some error occured please try again!!")
