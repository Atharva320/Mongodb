from pymongo import MongoClient
import certifi
from texttable import Texttable
try:
    client=MongoClient("mongodb+srv://New123:New123@cluster0.kpen7.mongodb.net/Office?retryWrites=true&w=majority",tlsCAFile=certifi.where())
    db=client["Office"]
    coll=db["Workers"]
    print("Hello,Here you can add a new worker")
    ID=input('Enter Employee ID : ')
    empnm=input('Enter Employee Name : ')
    dept=input('Enter Employee Department : ')
    post=input('Enter Employee Post : ')
    city=input('Enter Employee City : ')
    salary=int(input('Enter Employee Salary : '))
    mobiles=input('Enter Employee Mobile Number : ')
    email=input('Enter Employee Email : ')
    dic={}
    dic["_ID"]=ID
    dic["Name"]=empnm
    dic["Department"]=dept
    dic["Post"]=post
    dic["City"]=city
    dic["Salary"]=salary
    dic["Mobile"]=mobiles
    dic["Email"]=email
    t = Texttable()
    t.add_rows([['ID','Name','Salary','Mobile','Email'],[ID,empnm,salary,mobiles,email]])
    print(t.draw())
    ques=input('Are you sure you want to add this workers(Y/N) : ')
    q=ques.upper()
    if q=="Y":
        coll.insert_one(dic)
        print('New Worker Added Succesfully')
    else:
        print("Worker not Added")
   
except Exception as e:
    print("Some error occured,try again!!",e)